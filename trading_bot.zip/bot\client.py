"""
Binance Futures Testnet API Client.

Provides a clean interface for interacting with the Binance Futures Testnet API.
"""

import hashlib
import hmac
import os
import time
from typing import Any, Dict, Optional
from urllib.parse import urlencode

import requests
from dotenv import load_dotenv

from bot.logging_config import get_logger


class BinanceClientError(Exception):
    """Custom exception for Binance client errors."""
    
    def __init__(self, message: str, status_code: Optional[int] = None, error_code: Optional[int] = None):
        self.message = message
        self.status_code = status_code
        self.error_code = error_code
        super().__init__(self.message)


class AuthenticationError(BinanceClientError):
    """Exception for authentication-related errors."""
    pass


class NetworkError(BinanceClientError):
    """Exception for network-related errors."""
    pass


class APIError(BinanceClientError):
    """Exception for API-related errors."""
    pass


class BinanceClient:
    """
    Client for interacting with Binance Futures Testnet API.
    
    Handles authentication, request signing, and API communication.
    """

    BASE_URL = "https://testnet.binancefuture.com"
    
    # API Endpoints
    ENDPOINTS = {
        "order": "/fapi/v1/order",
        "exchange_info": "/fapi/v1/exchangeInfo",
        "account": "/fapi/v2/account",
        "ticker_price": "/fapi/v1/ticker/price",
        "server_time": "/fapi/v1/time",
    }

    def __init__(
        self,
        api_key: Optional[str] = None,
        api_secret: Optional[str] = None
    ) -> None:
        """
        Initialize the Binance client.

        Args:
            api_key: Binance API key (or from environment variable)
            api_secret: Binance API secret (or from environment variable)

        Raises:
            AuthenticationError: If API credentials are not provided
        """
        load_dotenv()
        
        self.api_key = api_key or os.getenv("BINANCE_API_KEY")
        self.api_secret = api_secret or os.getenv("BINANCE_API_SECRET")
        
        if not self.api_key or not self.api_secret:
            raise AuthenticationError(
                "API credentials not found. Please set BINANCE_API_KEY and "
                "BINANCE_API_SECRET environment variables or pass them directly."
            )
        
        self.logger = get_logger()
        self.session = requests.Session()
        self.session.headers.update({
            "X-MBX-APIKEY": self.api_key,
            "Content-Type": "application/x-www-form-urlencoded"
        })
        
        self.logger.info("Binance client initialized successfully")

    def _get_timestamp(self) -> int:
        """Get current timestamp in milliseconds."""
        return int(time.time() * 1000)

    def _generate_signature(self, params: Dict[str, Any]) -> str:
        """
        Generate HMAC SHA256 signature for request parameters.

        Args:
            params: Request parameters to sign

        Returns:
            Hex-encoded signature string
        """
        query_string = urlencode(params)
        signature = hmac.new(
            self.api_secret.encode("utf-8"),
            query_string.encode("utf-8"),
            hashlib.sha256
        ).hexdigest()
        return signature

    def _handle_response(self, response: requests.Response) -> Dict[str, Any]:
        """
        Handle API response and raise appropriate exceptions.

        Args:
            response: Response object from requests

        Returns:
            Parsed JSON response

        Raises:
            AuthenticationError: For authentication failures
            APIError: For API-specific errors
        """
        self.logger.debug(f"Response status: {response.status_code}")
        self.logger.debug(f"Response body: {response.text}")

        try:
            data = response.json()
        except ValueError:
            raise APIError(
                f"Invalid JSON response: {response.text}",
                status_code=response.status_code
            )

        if response.status_code >= 400:
            error_code = data.get("code", 0)
            error_msg = data.get("msg", "Unknown error")

            # Authentication errors
            if error_code in (-2014, -2015, -1022):
                raise AuthenticationError(
                    f"Authentication failed: {error_msg}",
                    status_code=response.status_code,
                    error_code=error_code
                )

            raise APIError(
                f"API Error: {error_msg} (code: {error_code})",
                status_code=response.status_code,
                error_code=error_code
            )

        return data

    def _request(
        self,
        method: str,
        endpoint: str,
        params: Optional[Dict[str, Any]] = None,
        signed: bool = False
    ) -> Dict[str, Any]:
        """
        Make an API request.

        Args:
            method: HTTP method (GET, POST, DELETE)
            endpoint: API endpoint
            params: Request parameters
            signed: Whether to sign the request

        Returns:
            API response as dictionary

        Raises:
            NetworkError: For connection issues
            APIError: For API errors
        """
        url = f"{self.BASE_URL}{endpoint}"
        params = params or {}

        if signed:
            params["timestamp"] = self._get_timestamp()
            params["signature"] = self._generate_signature(params)

        self.logger.debug(f"Request: {method} {url}")
        self.logger.debug(f"Parameters: {params}")

        try:
            if method == "GET":
                response = self.session.get(url, params=params, timeout=30)
            elif method == "POST":
                response = self.session.post(url, data=params, timeout=30)
            elif method == "DELETE":
                response = self.session.delete(url, params=params, timeout=30)
            else:
                raise ValueError(f"Unsupported HTTP method: {method}")

            return self._handle_response(response)

        except requests.exceptions.ConnectionError as e:
            self.logger.error(f"Connection error: {e}")
            raise NetworkError(f"Failed to connect to Binance API: {e}")
        except requests.exceptions.Timeout as e:
            self.logger.error(f"Request timeout: {e}")
            raise NetworkError(f"Request timed out: {e}")
        except requests.exceptions.RequestException as e:
            self.logger.error(f"Request failed: {e}")
            raise NetworkError(f"Request failed: {e}")

    def get_server_time(self) -> Dict[str, Any]:
        """
        Get Binance server time.

        Returns:
            Server time response
        """
        return self._request("GET", self.ENDPOINTS["server_time"])

    def get_exchange_info(self, symbol: Optional[str] = None) -> Dict[str, Any]:
        """
        Get exchange information.

        Args:
            symbol: Optional symbol to filter

        Returns:
            Exchange info response
        """
        params = {}
        if symbol:
            params["symbol"] = symbol.upper()
        return self._request("GET", self.ENDPOINTS["exchange_info"], params)

    def get_ticker_price(self, symbol: Optional[str] = None) -> Dict[str, Any]:
        """
        Get current ticker price.

        Args:
            symbol: Trading pair symbol

        Returns:
            Ticker price response
        """
        params = {}
        if symbol:
            params["symbol"] = symbol.upper()
        return self._request("GET", self.ENDPOINTS["ticker_price"], params)

    def get_account_info(self) -> Dict[str, Any]:
        """
        Get account information.

        Returns:
            Account info response
        """
        return self._request("GET", self.ENDPOINTS["account"], signed=True)

    def place_order(
        self,
        symbol: str,
        side: str,
        order_type: str,
        quantity: float,
        price: Optional[float] = None,
        stop_price: Optional[float] = None,
        time_in_force: str = "GTC"
    ) -> Dict[str, Any]:
        """
        Place a new order on Binance Futures Testnet.

        Args:
            symbol: Trading pair symbol (e.g., BTCUSDT)
            side: Order side (BUY or SELL)
            order_type: Order type (MARKET, LIMIT, STOP_LIMIT)
            quantity: Order quantity
            price: Limit price (required for LIMIT/STOP_LIMIT orders)
            stop_price: Stop trigger price (required for STOP_LIMIT orders)
            time_in_force: Time in force (GTC, IOC, FOK)

        Returns:
            Order response from the API

        Raises:
            APIError: If order placement fails
        """
        params: Dict[str, Any] = {
            "symbol": symbol.upper(),
            "side": side.upper(),
            "type": order_type.upper() if order_type.upper() != "STOP_LIMIT" else "STOP",
            "quantity": quantity,
        }

        # Add price for LIMIT and STOP_LIMIT orders
        if order_type.upper() in ("LIMIT", "STOP_LIMIT"):
            if price is not None:
                params["price"] = price
            params["timeInForce"] = time_in_force

        # Add stop price for STOP_LIMIT orders
        if order_type.upper() == "STOP_LIMIT" and stop_price is not None:
            params["stopPrice"] = stop_price

        self.logger.info(f"Placing order: {params}")

        response = self._request("POST", self.ENDPOINTS["order"], params, signed=True)

        self.logger.info(f"Order placed successfully: orderId={response.get('orderId')}")

        return response

    def cancel_order(self, symbol: str, order_id: int) -> Dict[str, Any]:
        """
        Cancel an existing order.

        Args:
            symbol: Trading pair symbol
            order_id: Order ID to cancel

        Returns:
            Cancellation response
        """
        params = {
            "symbol": symbol.upper(),
            "orderId": order_id
        }
        return self._request("DELETE", self.ENDPOINTS["order"], params, signed=True)

    def get_order(self, symbol: str, order_id: int) -> Dict[str, Any]:
        """
        Get order details.

        Args:
            symbol: Trading pair symbol
            order_id: Order ID

        Returns:
            Order details response
        """
        params = {
            "symbol": symbol.upper(),
            "orderId": order_id
        }
        return self._request("GET", self.ENDPOINTS["order"], params, signed=True)
