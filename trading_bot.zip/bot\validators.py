"""
Validation module for order parameters.

Provides comprehensive validation for all order-related inputs.
"""

import re
from dataclasses import dataclass
from decimal import Decimal, InvalidOperation
from enum import Enum
from typing import Optional, Tuple

from bot.logging_config import get_logger


class OrderSide(str, Enum):
    """Order side enumeration."""
    BUY = "BUY"
    SELL = "SELL"


class OrderType(str, Enum):
    """Order type enumeration."""
    MARKET = "MARKET"
    LIMIT = "LIMIT"
    STOP_LIMIT = "STOP_LIMIT"


@dataclass
class ValidationResult:
    """Result of a validation operation."""
    is_valid: bool
    error_message: Optional[str] = None


class OrderValidator:
    """
    Validator class for order parameters.
    
    Validates symbol format, quantity, price, and order parameters
    before submission to the exchange.
    """

    # Symbol pattern: uppercase letters followed by USDT/BUSD/etc.
    SYMBOL_PATTERN = re.compile(r"^[A-Z]{2,10}USDT$")
    
    # Minimum quantity (can be adjusted based on exchange requirements)
    MIN_QUANTITY = Decimal("0.00000001")
    
    # Minimum price
    MIN_PRICE = Decimal("0.00000001")

    def __init__(self) -> None:
        """Initialize the validator."""
        self.logger = get_logger()

    def validate_symbol(self, symbol: str) -> ValidationResult:
        """
        Validate trading symbol format.

        Args:
            symbol: Trading pair symbol (e.g., BTCUSDT)

        Returns:
            ValidationResult indicating success or failure with message
        """
        if not symbol:
            return ValidationResult(False, "Symbol cannot be empty")

        symbol = symbol.upper().strip()
        
        if not self.SYMBOL_PATTERN.match(symbol):
            return ValidationResult(
                False,
                f"Invalid symbol format: {symbol}. Expected format: XXXUSDT (e.g., BTCUSDT)"
            )

        self.logger.debug(f"Symbol validation passed: {symbol}")
        return ValidationResult(True)

    def validate_quantity(self, quantity: str | float | Decimal) -> ValidationResult:
        """
        Validate order quantity.

        Args:
            quantity: Order quantity

        Returns:
            ValidationResult indicating success or failure with message
        """
        try:
            qty = Decimal(str(quantity))
        except (InvalidOperation, ValueError):
            return ValidationResult(
                False,
                f"Invalid quantity format: {quantity}. Must be a valid number"
            )

        if qty <= 0:
            return ValidationResult(
                False,
                f"Quantity must be greater than 0. Received: {quantity}"
            )

        if qty < self.MIN_QUANTITY:
            return ValidationResult(
                False,
                f"Quantity {quantity} is below minimum: {self.MIN_QUANTITY}"
            )

        self.logger.debug(f"Quantity validation passed: {quantity}")
        return ValidationResult(True)

    def validate_price(
        self,
        price: Optional[str | float | Decimal],
        order_type: OrderType
    ) -> ValidationResult:
        """
        Validate order price based on order type.

        Args:
            price: Order price (required for LIMIT and STOP_LIMIT orders)
            order_type: Type of the order

        Returns:
            ValidationResult indicating success or failure with message
        """
        requires_price = order_type in (OrderType.LIMIT, OrderType.STOP_LIMIT)

        if requires_price:
            if price is None:
                return ValidationResult(
                    False,
                    f"Price is required for {order_type.value} orders"
                )

            try:
                price_decimal = Decimal(str(price))
            except (InvalidOperation, ValueError):
                return ValidationResult(
                    False,
                    f"Invalid price format: {price}. Must be a valid number"
                )

            if price_decimal <= 0:
                return ValidationResult(
                    False,
                    f"Price must be greater than 0. Received: {price}"
                )

            if price_decimal < self.MIN_PRICE:
                return ValidationResult(
                    False,
                    f"Price {price} is below minimum: {self.MIN_PRICE}"
                )

        self.logger.debug(f"Price validation passed: {price}")
        return ValidationResult(True)

    def validate_stop_price(
        self,
        stop_price: Optional[str | float | Decimal],
        order_type: OrderType
    ) -> ValidationResult:
        """
        Validate stop price for STOP_LIMIT orders.

        Args:
            stop_price: Stop trigger price
            order_type: Type of the order

        Returns:
            ValidationResult indicating success or failure with message
        """
        if order_type != OrderType.STOP_LIMIT:
            return ValidationResult(True)

        if stop_price is None:
            return ValidationResult(
                False,
                "Stop price is required for STOP_LIMIT orders"
            )

        try:
            stop_price_decimal = Decimal(str(stop_price))
        except (InvalidOperation, ValueError):
            return ValidationResult(
                False,
                f"Invalid stop price format: {stop_price}. Must be a valid number"
            )

        if stop_price_decimal <= 0:
            return ValidationResult(
                False,
                f"Stop price must be greater than 0. Received: {stop_price}"
            )

        self.logger.debug(f"Stop price validation passed: {stop_price}")
        return ValidationResult(True)

    def validate_side(self, side: str) -> ValidationResult:
        """
        Validate order side.

        Args:
            side: Order side (BUY or SELL)

        Returns:
            ValidationResult indicating success or failure with message
        """
        side = side.upper().strip()
        
        try:
            OrderSide(side)
        except ValueError:
            valid_sides = [s.value for s in OrderSide]
            return ValidationResult(
                False,
                f"Invalid order side: {side}. Must be one of: {valid_sides}"
            )

        self.logger.debug(f"Side validation passed: {side}")
        return ValidationResult(True)

    def validate_order_type(self, order_type: str) -> ValidationResult:
        """
        Validate order type.

        Args:
            order_type: Type of order (MARKET, LIMIT, STOP_LIMIT)

        Returns:
            ValidationResult indicating success or failure with message
        """
        order_type = order_type.upper().strip()
        
        try:
            OrderType(order_type)
        except ValueError:
            valid_types = [t.value for t in OrderType]
            return ValidationResult(
                False,
                f"Invalid order type: {order_type}. Must be one of: {valid_types}"
            )

        self.logger.debug(f"Order type validation passed: {order_type}")
        return ValidationResult(True)

    def validate_order(
        self,
        symbol: str,
        side: str,
        order_type: str,
        quantity: str | float | Decimal,
        price: Optional[str | float | Decimal] = None,
        stop_price: Optional[str | float | Decimal] = None
    ) -> Tuple[bool, Optional[str]]:
        """
        Validate all order parameters.

        Args:
            symbol: Trading pair symbol
            side: Order side (BUY/SELL)
            order_type: Order type (MARKET/LIMIT/STOP_LIMIT)
            quantity: Order quantity
            price: Order price (required for LIMIT/STOP_LIMIT)
            stop_price: Stop trigger price (required for STOP_LIMIT)

        Returns:
            Tuple of (is_valid, error_message)
        """
        self.logger.info(f"Validating order: {symbol} {side} {order_type} qty={quantity}")

        # Validate symbol
        result = self.validate_symbol(symbol)
        if not result.is_valid:
            return False, result.error_message

        # Validate side
        result = self.validate_side(side)
        if not result.is_valid:
            return False, result.error_message

        # Validate order type
        result = self.validate_order_type(order_type)
        if not result.is_valid:
            return False, result.error_message

        # Get validated order type enum
        validated_order_type = OrderType(order_type.upper())

        # Validate quantity
        result = self.validate_quantity(quantity)
        if not result.is_valid:
            return False, result.error_message

        # Validate price
        result = self.validate_price(price, validated_order_type)
        if not result.is_valid:
            return False, result.error_message

        # Validate stop price
        result = self.validate_stop_price(stop_price, validated_order_type)
        if not result.is_valid:
            return False, result.error_message

        self.logger.info("Order validation successful")
        return True, None
