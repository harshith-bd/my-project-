"""
Binance Futures Testnet Trading Bot Package.

This package provides modules for interacting with Binance Futures Testnet API.
"""

from bot.client import BinanceClient
from bot.orders import OrderManager
from bot.validators import OrderValidator

__all__ = ["BinanceClient", "OrderManager", "OrderValidator"]
__version__ = "1.0.0"
