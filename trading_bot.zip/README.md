# Binance Futures Testnet Trading Bot

A command-line interface (CLI) application for placing orders on Binance Futures Testnet (USDT-M).

## Features

- **Order Types**: Market, Limit, and Stop-Limit orders
- **Order Sides**: Buy and Sell
- **Clean CLI**: Built with Typer for an intuitive user experience
- **Structured Logging**: All API requests and responses logged to file
- **Input Validation**: Comprehensive validation before order submission
- **Error Handling**: Graceful handling of network, auth, and API errors
- **Modular Design**: Clean separation of concerns for maintainability

## Project Structure

```
trading_bot/
├── bot/
│   ├── __init__.py         # Package initialization
│   ├── client.py           # Binance API client
│   ├── orders.py           # Order management
│   ├── validators.py       # Input validation
│   └── logging_config.py   # Logging configuration
├── cli.py                  # CLI entry point
├── requirements.txt        # Dependencies
├── .env.example           # Environment variables template
└── README.md              # Documentation
```

## Prerequisites

- Python 3.9 or higher
- Binance Futures Testnet account
- API Key and Secret from Binance Testnet

## Setup

### 1. Create Binance Futures Testnet Account & API Keys

1. Go to [Binance Futures Testnet](https://testnet.binancefuture.com/)
2. Click "Log In with GitHub" or create an account
3. After logging in, go to the API Management section
4. Generate a new API Key and Secret
5. **Important**: Save both the API Key and Secret immediately (the secret is only shown once)

### 2. Clone/Download the Project

```bash
cd trading_bot
```

### 3. Create Virtual Environment (Recommended)

```bash
# Create virtual environment
python -m venv venv

# Activate (Windows)
venv\Scripts\activate

# Activate (macOS/Linux)
source venv/bin/activate
```

### 4. Install Dependencies

```bash
pip install -r requirements.txt
```

### 5. Configure Environment Variables

```bash
# Copy the example file
cp .env.example .env

# Edit .env and add your credentials
# BINANCE_API_KEY=your_api_key_here
# BINANCE_API_SECRET=your_api_secret_here
```

**Windows (PowerShell)**:
```powershell
copy .env.example .env
```

Then edit the `.env` file with your API credentials.

## CLI Usage

### View Help

```bash
python cli.py --help
```

### Place Orders

#### Generic Order Command

```bash
python cli.py order --symbol BTCUSDT --side BUY --type MARKET --quantity 0.001
```

#### Market Order (Shortcut)

```bash
# Buy 0.001 BTC at market price
python cli.py market -s BTCUSDT --side BUY -q 0.001

# Sell 0.001 BTC at market price
python cli.py market -s BTCUSDT --side SELL -q 0.001
```

#### Limit Order (Shortcut)

```bash
# Buy 0.001 BTC at $50,000
python cli.py limit -s BTCUSDT --side BUY -q 0.001 -p 50000

# Sell 0.001 BTC at $55,000
python cli.py limit -s BTCUSDT --side SELL -q 0.001 -p 55000
```

#### Stop-Limit Order (Shortcut)

```bash
# Buy when price reaches $50,000 (stop), execute at $51,000 (limit)
python cli.py stop-limit -s BTCUSDT --side BUY -q 0.001 -p 51000 -sp 50000

# Sell when price drops to $45,000 (stop), execute at $44,500 (limit)
python cli.py stop-limit -s BTCUSDT --side SELL -q 0.001 -p 44500 -sp 45000
```

### Skip Confirmation

Add `--no-confirm` to skip the confirmation prompt:

```bash
python cli.py market -s BTCUSDT --side BUY -q 0.001 --no-confirm
```

### Get Current Price

```bash
python cli.py price -s BTCUSDT
```

### View Account Balance

```bash
python cli.py account
```

## CLI Options

### Order Command Options

| Option | Short | Description | Required |
|--------|-------|-------------|----------|
| `--symbol` | `-s` | Trading pair (e.g., BTCUSDT) | Yes |
| `--side` | | Order side (BUY/SELL) | Yes |
| `--type` | `-t` | Order type (MARKET/LIMIT/STOP_LIMIT) | Yes |
| `--quantity` | `-q` | Order quantity | Yes |
| `--price` | `-p` | Limit price | For LIMIT/STOP_LIMIT |
| `--stop-price` | `-sp` | Stop trigger price | For STOP_LIMIT |
| `--confirm/--no-confirm` | | Confirmation prompt | No (default: confirm) |

## Example Commands

```bash
# Market buy
python cli.py order -s ETHUSDT --side BUY -t MARKET -q 0.01

# Limit sell
python cli.py order -s BTCUSDT --side SELL -t LIMIT -q 0.001 -p 60000

# Stop-limit buy (protect against missing a breakout)
python cli.py order -s BTCUSDT --side BUY -t STOP_LIMIT -q 0.001 -p 52000 -sp 51000

# Quick commands
python cli.py market -s BTCUSDT --side BUY -q 0.001
python cli.py limit -s ETHUSDT --side SELL -q 0.05 -p 3500
python cli.py stop-limit -s BTCUSDT --side SELL -q 0.001 -p 48000 -sp 49000
```

## Logging

Logs are stored in the `logs/` directory with timestamped filenames:

```
logs/trading_bot_20240101_120000.log
```

Log entries include:
- Timestamp
- Log level (DEBUG, INFO, WARNING, ERROR)
- Module and function name
- Line number
- Message

Example log entry:
```
2024-01-01 12:00:00 | INFO     | trading_bot | place_order:45 | Placing order: {'symbol': 'BTCUSDT', 'side': 'BUY', 'type': 'MARKET', 'quantity': 0.001}
```

## Error Handling

The bot handles various error scenarios:

- **Invalid Symbol**: Format must match pattern (e.g., BTCUSDT)
- **Invalid Order Type**: Must be MARKET, LIMIT, or STOP_LIMIT
- **Invalid Side**: Must be BUY or SELL
- **Missing Price**: Required for LIMIT and STOP_LIMIT orders
- **Missing Stop Price**: Required for STOP_LIMIT orders
- **Network Errors**: Connection timeouts and failures
- **API Errors**: Invalid API response or exchange errors
- **Authentication Errors**: Invalid or missing API credentials

## Supported Symbols

Common trading pairs on Binance Futures Testnet:
- BTCUSDT
- ETHUSDT
- BNBUSDT
- XRPUSDT
- ADAUSDT
- DOGEUSDT
- SOLUSDT
- And many more...

## Assumptions

1. **Testnet Only**: This bot is designed for Binance Futures Testnet only
2. **USDT-M Futures**: Only USDT-margined futures are supported
3. **Symbol Format**: All symbols must end with USDT
4. **Time in Force**: LIMIT orders use GTC (Good Till Cancelled) by default
5. **No Position Management**: This bot focuses on order placement only

## Troubleshooting

### API Key Issues

If you see authentication errors:
1. Verify your API key and secret are correct
2. Ensure the `.env` file is in the `trading_bot` directory
3. Check that the keys are from the **Testnet**, not the live exchange

### Network Errors

If you experience connection issues:
1. Check your internet connection
2. Verify the Testnet API is accessible: https://testnet.binancefuture.com
3. Try increasing the timeout in `client.py`

### Order Rejection

If orders are rejected:
1. Check the symbol is valid on Testnet
2. Verify the quantity meets minimum requirements
3. For LIMIT orders, ensure the price is reasonable
4. Check your Testnet account has sufficient balance

## Security Notes

- Never commit your `.env` file to version control
- Keep your API keys secure
- Use Testnet keys only on Testnet
- The `.env.example` file is safe to commit

## License

This project is for educational purposes. Use at your own risk.
