"""
Order management module.

Provides high-level order management functionality with validation.
"""

from dataclasses import dataclass
from decimal import Decimal
from typing import Any, Dict, Optional

from bot.client import BinanceClient, BinanceClientError
from bot.logging_config import get_logger
from bot.validators import OrderValidator


@dataclass
class OrderResult:
    """Result of an order operation."""
    success: bool
    order_id: Optional[int] = None
    status: Optional[str] = None
    executed_qty: Optional[str] = None
    avg_price: Optional[str] = None
    symbol: Optional[str] = None
    side: Optional[str] = None
    order_type: Optional[str] = None
    original_qty: Optional[str] = None
    price: Optional[str] = None
    error_message: Optional[str] = None
    raw_response: Optional[Dict[str, Any]] = None

    def to_display_dict(self) -> Dict[str, Any]:
        """Convert to a dictionary for display purposes."""
        return {
            "success": self.success,
            "order_id": self.order_id,
            "symbol": self.symbol,
            "side": self.side,
            "type": self.order_type,
            "status": self.status,
            "original_qty": self.original_qty,
            "executed_qty": self.executed_qty,
            "price": self.price,
            "avg_price": self.avg_price,
            "error": self.error_message
        }


class OrderManager:
    """
    High-level order management with validation.
    
    Provides a clean interface for placing orders with proper
    validation and error handling.
    """

    def __init__(self, client: Optional[BinanceClient] = None) -> None:
        """
        Initialize the order manager.

        Args:
            client: Optional BinanceClient instance (creates one if not provided)
        """
        self.logger = get_logger()
        self.validator = OrderValidator()
        self.client = client or BinanceClient()

    def place_market_order(
        self,
        symbol: str,
        side: str,
        quantity: float | str | Decimal
    ) -> OrderResult:
        """
        Place a market order.

        Args:
            symbol: Trading pair symbol (e.g., BTCUSDT)
            side: Order side (BUY or SELL)
            quantity: Order quantity

        Returns:
            OrderResult with order details or error information
        """
        return self._place_order(
            symbol=symbol,
            side=side,
            order_type="MARKET",
            quantity=quantity
        )

    def place_limit_order(
        self,
        symbol: str,
        side: str,
        quantity: float | str | Decimal,
        price: float | str | Decimal
    ) -> OrderResult:
        """
        Place a limit order.

        Args:
            symbol: Trading pair symbol (e.g., BTCUSDT)
            side: Order side (BUY or SELL)
            quantity: Order quantity
            price: Limit price

        Returns:
            OrderResult with order details or error information
        """
        return self._place_order(
            symbol=symbol,
            side=side,
            order_type="LIMIT",
            quantity=quantity,
            price=price
        )

    def place_stop_limit_order(
        self,
        symbol: str,
        side: str,
        quantity: float | str | Decimal,
        price: float | str | Decimal,
        stop_price: float | str | Decimal
    ) -> OrderResult:
        """
        Place a stop-limit order.

        Args:
            symbol: Trading pair symbol (e.g., BTCUSDT)
            side: Order side (BUY or SELL)
            quantity: Order quantity
            price: Limit price (executed when stop is triggered)
            stop_price: Stop trigger price

        Returns:
            OrderResult with order details or error information
        """
        return self._place_order(
            symbol=symbol,
            side=side,
            order_type="STOP_LIMIT",
            quantity=quantity,
            price=price,
            stop_price=stop_price
        )

    def _place_order(
        self,
        symbol: str,
        side: str,
        order_type: str,
        quantity: float | str | Decimal,
        price: Optional[float | str | Decimal] = None,
        stop_price: Optional[float | str | Decimal] = None
    ) -> OrderResult:
        """
        Internal method to place an order with validation.

        Args:
            symbol: Trading pair symbol
            side: Order side
            order_type: Order type
            quantity: Order quantity
            price: Optional limit price
            stop_price: Optional stop price

        Returns:
            OrderResult with order details or error information
        """
        # Normalize inputs
        symbol = symbol.upper().strip()
        side = side.upper().strip()
        order_type = order_type.upper().strip()

        # Validate order parameters
        is_valid, error_msg = self.validator.validate_order(
            symbol=symbol,
            side=side,
            order_type=order_type,
            quantity=quantity,
            price=price,
            stop_price=stop_price
        )

        if not is_valid:
            self.logger.error(f"Order validation failed: {error_msg}")
            return OrderResult(success=False, error_message=error_msg)

        # Convert to float for API
        qty_float = float(Decimal(str(quantity)))
        price_float = float(Decimal(str(price))) if price else None
        stop_price_float = float(Decimal(str(stop_price))) if stop_price else None

        try:
            self.logger.info(
                f"Placing {order_type} order: {side} {qty_float} {symbol} "
                f"@ {price_float if price_float else 'MARKET'}"
            )

            response = self.client.place_order(
                symbol=symbol,
                side=side,
                order_type=order_type,
                quantity=qty_float,
                price=price_float,
                stop_price=stop_price_float
            )

            # Parse response
            result = OrderResult(
                success=True,
                order_id=response.get("orderId"),
                status=response.get("status"),
                executed_qty=response.get("executedQty"),
                avg_price=response.get("avgPrice"),
                symbol=response.get("symbol"),
                side=response.get("side"),
                order_type=response.get("type"),
                original_qty=response.get("origQty"),
                price=response.get("price"),
                raw_response=response
            )

            self.logger.info(
                f"Order placed successfully: orderId={result.order_id}, "
                f"status={result.status}, executedQty={result.executed_qty}"
            )

            return result

        except BinanceClientError as e:
            self.logger.error(f"Order placement failed: {e.message}")
            return OrderResult(
                success=False,
                error_message=e.message
            )

    def get_order_summary(self, result: OrderResult) -> str:
        """
        Generate a human-readable order summary.

        Args:
            result: OrderResult to summarize

        Returns:
            Formatted string summary
        """
        if not result.success:
            return f"Order Failed: {result.error_message}"

        lines = [
            "=" * 50,
            "ORDER EXECUTED SUCCESSFULLY",
            "=" * 50,
            f"Order ID:      {result.order_id}",
            f"Symbol:        {result.symbol}",
            f"Side:          {result.side}",
            f"Type:          {result.order_type}",
            f"Status:        {result.status}",
            f"Original Qty:  {result.original_qty}",
            f"Executed Qty:  {result.executed_qty}",
        ]

        if result.price and result.price != "0":
            lines.append(f"Price:         {result.price}")
        
        if result.avg_price and result.avg_price != "0":
            lines.append(f"Avg Price:     {result.avg_price}")

        lines.append("=" * 50)

        return "\n".join(lines)
