#!/usr/bin/env python3
"""
Binance Futures Testnet Trading Bot CLI.

Command-line interface for placing orders on Binance Futures Testnet.
"""

from typing import Optional

import typer
from rich.console import Console
from rich.panel import Panel
from rich.table import Table

from bot.client import AuthenticationError, BinanceClientError, NetworkError
from bot.logging_config import setup_logging
from bot.orders import OrderManager, OrderResult

# Initialize Typer app
app = typer.Typer(
    name="trading-bot",
    help="Binance Futures Testnet Trading Bot - Place orders via CLI",
    add_completion=False
)

console = Console()


def display_order_request(
    symbol: str,
    side: str,
    order_type: str,
    quantity: float,
    price: Optional[float] = None,
    stop_price: Optional[float] = None
) -> None:
    """Display order request summary before execution."""
    table = Table(title="Order Request Summary", show_header=True, header_style="bold cyan")
    table.add_column("Parameter", style="dim")
    table.add_column("Value", style="bold")

    table.add_row("Symbol", symbol.upper())
    table.add_row("Side", side.upper())
    table.add_row("Type", order_type.upper())
    table.add_row("Quantity", str(quantity))
    
    if price is not None:
        table.add_row("Price", str(price))
    
    if stop_price is not None:
        table.add_row("Stop Price", str(stop_price))

    console.print(table)
    console.print()


def display_order_result(result: OrderResult) -> None:
    """Display order result after execution."""
    if result.success:
        table = Table(title="Order Executed Successfully", show_header=True, header_style="bold green")
        table.add_column("Field", style="dim")
        table.add_column("Value", style="bold")

        table.add_row("Order ID", str(result.order_id))
        table.add_row("Symbol", result.symbol or "N/A")
        table.add_row("Side", result.side or "N/A")
        table.add_row("Type", result.order_type or "N/A")
        table.add_row("Status", result.status or "N/A")
        table.add_row("Original Qty", result.original_qty or "N/A")
        table.add_row("Executed Qty", result.executed_qty or "N/A")
        
        if result.price and result.price != "0":
            table.add_row("Price", result.price)
        
        if result.avg_price and result.avg_price != "0":
            table.add_row("Avg Price", result.avg_price)

        console.print(table)
        console.print(Panel("[bold green]SUCCESS:[/bold green] Order placed successfully!", border_style="green"))
    else:
        console.print(Panel(
            f"[bold red]FAILED:[/bold red] {result.error_message}",
            title="Order Failed",
            border_style="red"
        ))


@app.command("order")
def place_order(
    symbol: str = typer.Option(
        ...,
        "--symbol", "-s",
        help="Trading pair symbol (e.g., BTCUSDT)",
        prompt="Enter trading symbol"
    ),
    side: str = typer.Option(
        ...,
        "--side",
        help="Order side: BUY or SELL",
        prompt="Enter order side (BUY/SELL)"
    ),
    order_type: str = typer.Option(
        ...,
        "--type", "-t",
        help="Order type: MARKET, LIMIT, or STOP_LIMIT",
        prompt="Enter order type (MARKET/LIMIT/STOP_LIMIT)"
    ),
    quantity: float = typer.Option(
        ...,
        "--quantity", "-q",
        help="Order quantity",
        prompt="Enter quantity"
    ),
    price: Optional[float] = typer.Option(
        None,
        "--price", "-p",
        help="Limit price (required for LIMIT and STOP_LIMIT orders)"
    ),
    stop_price: Optional[float] = typer.Option(
        None,
        "--stop-price", "-sp",
        help="Stop trigger price (required for STOP_LIMIT orders)"
    ),
    confirm: bool = typer.Option(
        True,
        "--confirm/--no-confirm",
        help="Confirm before placing order"
    )
) -> None:
    """
    Place an order on Binance Futures Testnet.

    Examples:

        # Market order
        python cli.py order -s BTCUSDT --side BUY -t MARKET -q 0.001

        # Limit order
        python cli.py order -s BTCUSDT --side SELL -t LIMIT -q 0.001 -p 50000

        # Stop-limit order
        python cli.py order -s BTCUSDT --side BUY -t STOP_LIMIT -q 0.001 -p 51000 -sp 50000
    """
    # Setup logging
    logger = setup_logging()

    # Normalize inputs
    symbol = symbol.upper().strip()
    side = side.upper().strip()
    order_type = order_type.upper().strip()

    # Validate price requirements
    if order_type in ("LIMIT", "STOP_LIMIT") and price is None:
        console.print(Panel(
            f"[bold red]ERROR:[/bold red] Price is required for {order_type} orders",
            border_style="red"
        ))
        raise typer.Exit(1)

    if order_type == "STOP_LIMIT" and stop_price is None:
        console.print(Panel(
            "[bold red]ERROR:[/bold red] Stop price is required for STOP_LIMIT orders",
            border_style="red"
        ))
        raise typer.Exit(1)

    # Display order request
    console.print()
    display_order_request(symbol, side, order_type, quantity, price, stop_price)

    # Confirm order
    if confirm:
        if not typer.confirm("Do you want to place this order?"):
            console.print("[yellow]Order cancelled by user.[/yellow]")
            raise typer.Exit(0)

    console.print()
    console.print("[bold]Placing order...[/bold]")

    try:
        # Initialize order manager and place order
        order_manager = OrderManager()

        if order_type == "MARKET":
            result = order_manager.place_market_order(symbol, side, quantity)
        elif order_type == "LIMIT":
            result = order_manager.place_limit_order(symbol, side, quantity, price)
        elif order_type == "STOP_LIMIT":
            result = order_manager.place_stop_limit_order(
                symbol, side, quantity, price, stop_price
            )
        else:
            console.print(Panel(
                f"[bold red]ERROR:[/bold red] Unknown order type: {order_type}",
                border_style="red"
            ))
            raise typer.Exit(1)

        # Display result
        console.print()
        display_order_result(result)

        if not result.success:
            raise typer.Exit(1)

    except AuthenticationError as e:
        logger.error(f"Authentication error: {e.message}")
        console.print(Panel(
            f"[bold red]AUTHENTICATION ERROR:[/bold red]\n{e.message}\n\n"
            "Please check your API credentials in the .env file.",
            border_style="red"
        ))
        raise typer.Exit(1)

    except NetworkError as e:
        logger.error(f"Network error: {e.message}")
        console.print(Panel(
            f"[bold red]NETWORK ERROR:[/bold red]\n{e.message}\n\n"
            "Please check your internet connection.",
            border_style="red"
        ))
        raise typer.Exit(1)

    except BinanceClientError as e:
        logger.error(f"Client error: {e.message}")
        console.print(Panel(
            f"[bold red]ERROR:[/bold red]\n{e.message}",
            border_style="red"
        ))
        raise typer.Exit(1)


@app.command("market")
def market_order(
    symbol: str = typer.Option(
        ...,
        "--symbol", "-s",
        help="Trading pair symbol (e.g., BTCUSDT)"
    ),
    side: str = typer.Option(
        ...,
        "--side",
        help="Order side: BUY or SELL"
    ),
    quantity: float = typer.Option(
        ...,
        "--quantity", "-q",
        help="Order quantity"
    ),
    confirm: bool = typer.Option(
        True,
        "--confirm/--no-confirm",
        help="Confirm before placing order"
    )
) -> None:
    """
    Place a MARKET order (shortcut command).

    Example:
        python cli.py market -s BTCUSDT --side BUY -q 0.001
    """
    place_order(symbol, side, "MARKET", quantity, None, None, confirm)


@app.command("limit")
def limit_order(
    symbol: str = typer.Option(
        ...,
        "--symbol", "-s",
        help="Trading pair symbol (e.g., BTCUSDT)"
    ),
    side: str = typer.Option(
        ...,
        "--side",
        help="Order side: BUY or SELL"
    ),
    quantity: float = typer.Option(
        ...,
        "--quantity", "-q",
        help="Order quantity"
    ),
    price: float = typer.Option(
        ...,
        "--price", "-p",
        help="Limit price"
    ),
    confirm: bool = typer.Option(
        True,
        "--confirm/--no-confirm",
        help="Confirm before placing order"
    )
) -> None:
    """
    Place a LIMIT order (shortcut command).

    Example:
        python cli.py limit -s BTCUSDT --side SELL -q 0.001 -p 50000
    """
    place_order(symbol, side, "LIMIT", quantity, price, None, confirm)


@app.command("stop-limit")
def stop_limit_order(
    symbol: str = typer.Option(
        ...,
        "--symbol", "-s",
        help="Trading pair symbol (e.g., BTCUSDT)"
    ),
    side: str = typer.Option(
        ...,
        "--side",
        help="Order side: BUY or SELL"
    ),
    quantity: float = typer.Option(
        ...,
        "--quantity", "-q",
        help="Order quantity"
    ),
    price: float = typer.Option(
        ...,
        "--price", "-p",
        help="Limit price (executed when stop triggers)"
    ),
    stop_price: float = typer.Option(
        ...,
        "--stop-price", "-sp",
        help="Stop trigger price"
    ),
    confirm: bool = typer.Option(
        True,
        "--confirm/--no-confirm",
        help="Confirm before placing order"
    )
) -> None:
    """
    Place a STOP-LIMIT order (shortcut command).

    Example:
        python cli.py stop-limit -s BTCUSDT --side BUY -q 0.001 -p 51000 -sp 50000
    """
    place_order(symbol, side, "STOP_LIMIT", quantity, price, stop_price, confirm)


@app.command("price")
def get_price(
    symbol: str = typer.Option(
        ...,
        "--symbol", "-s",
        help="Trading pair symbol (e.g., BTCUSDT)"
    )
) -> None:
    """
    Get current price for a symbol.

    Example:
        python cli.py price -s BTCUSDT
    """
    from bot.client import BinanceClient

    logger = setup_logging()

    try:
        # Create client without credentials for public endpoint
        import os
        from dotenv import load_dotenv
        load_dotenv()
        
        api_key = os.getenv("BINANCE_API_KEY")
        api_secret = os.getenv("BINANCE_API_SECRET")
        
        if not api_key or not api_secret:
            console.print(Panel(
                "[bold red]ERROR:[/bold red] API credentials not found in .env file",
                border_style="red"
            ))
            raise typer.Exit(1)
            
        client = BinanceClient(api_key, api_secret)
        result = client.get_ticker_price(symbol)

        console.print(Panel(
            f"[bold cyan]{result['symbol']}[/bold cyan]: [bold green]{result['price']}[/bold green]",
            title="Current Price",
            border_style="cyan"
        ))

    except BinanceClientError as e:
        logger.error(f"Error getting price: {e.message}")
        console.print(Panel(
            f"[bold red]ERROR:[/bold red] {e.message}",
            border_style="red"
        ))
        raise typer.Exit(1)


@app.command("account")
def get_account() -> None:
    """
    Get account information.

    Example:
        python cli.py account
    """
    from bot.client import BinanceClient

    logger = setup_logging()

    try:
        client = BinanceClient()
        result = client.get_account_info()

        table = Table(title="Account Information", show_header=True, header_style="bold cyan")
        table.add_column("Asset", style="dim")
        table.add_column("Wallet Balance", style="bold")
        table.add_column("Available", style="green")

        for asset in result.get("assets", []):
            wallet_balance = float(asset.get("walletBalance", 0))
            if wallet_balance > 0:
                table.add_row(
                    asset.get("asset", "N/A"),
                    asset.get("walletBalance", "0"),
                    asset.get("availableBalance", "0")
                )

        console.print(table)

    except BinanceClientError as e:
        logger.error(f"Error getting account: {e.message}")
        console.print(Panel(
            f"[bold red]ERROR:[/bold red] {e.message}",
            border_style="red"
        ))
        raise typer.Exit(1)


@app.callback()
def main() -> None:
    """
    Binance Futures Testnet Trading Bot.

    A CLI tool for placing orders on Binance Futures Testnet.
    Supports MARKET, LIMIT, and STOP-LIMIT orders.
    """
    pass


if __name__ == "__main__":
    app()
